javac *.java
jar -cfm Samples.jar manifest.stub *.class
